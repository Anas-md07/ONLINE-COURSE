# Upgrade Plan: SpringBootEmp (20260803063717)

- **Generated**: 2026-08-03 06:37:17
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17.0.12: C:\Program Files\Java\jdk-17\bin (current project JDK, used for baseline)
- JDK 25: **<TO_BE_INSTALLED>** (required by step 3 and final validation)

**Build Tools**
- Maven Wrapper: 3.9.10 (already configured in .mvn/wrapper/maven-wrapper.properties)

## Guidelines

- Upgrade the Java runtime to the latest LTS version available in this environment.
- Preserve application behavior while modernizing for the newer runtime.
- Prefer compatibility-safe changes and verify with compilation and tests.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260803063717
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible | Why Incompatible |
| ---------------------- | ------- | -------------- | ---------------- |
| Java | 17 | 25 | User requested |
| Spring Boot | 2.7.0 | 3.5.0 | Java 25 requires a modern Spring Boot line |
| Spring Security DSL | old `authorizeRequests()` style | Spring Security 6 | Removed/changed in Spring Security 6 |
| Jakarta Persistence imports | `javax.persistence.*` | `jakarta.persistence.*` | Spring Boot 3 uses Jakarta EE 10 APIs |
| springdoc OpenAPI | 1.7.0 | 2.x | Older artifact line is not the recommended Boot 3-compatible path |

## Derived Upgrades

- Spring Boot 3.5.x from 2.7.0 to align with Java 25 and Jakarta EE 10.
- Spring Framework 6.2.x and Spring Security 6.x via the Spring Boot 3.5 parent.
- Jakarta persistence imports migrated from `javax.persistence` to `jakarta.persistence`.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | spring-boot-starter-parent | 2.7.0 | upgrade | 3.5.0 | Align with Java 25 and Spring 6.2 |
| pom.xml | java.version | 17 | upgrade | 25 | User requested |
| pom.xml | springdoc-openapi-ui | 1.7.0 | replace | springdoc-openapi-starter-webmvc-ui 2.8.0 | Boot 3-compatible OpenAPI starter |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| src/main/java/com/examly/springapp/configuration/SecurityConfig.java | security DSL | `authorizeRequests()` | Replace with `authorizeHttpRequests()` and `requestMatchers()` | Spring Security 6 API change |
| src/main/java/com/examly/springapp/model/*.java | imports | `javax.persistence.*` | Replace with `jakarta.persistence.*` | Spring Boot 3/Jakarta namespace |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| pom.xml | compiler target | `${java.version}` | Keep aligned with Java 25 | Runtime compatibility |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None | - | - | No CI files found in the project root |

### Risks & Warnings

- Spring Security 6 configuration syntax is materially different from the old DSL. Mitigation: update to the modern `authorizeHttpRequests()` style and verify with the test suite.
- Several entity classes use `javax.persistence` imports that will fail under Spring Boot 3. Mitigation: migrate them consistently to `jakarta.persistence`.
- The environment currently lacks a Java 25 runtime, so the build must be verified after installation. Mitigation: install JDK 25 before compilation.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: A Java 25 toolchain is required to compile and run the upgraded project.
  - **Changes to Make**: Install JDK 25 and confirm Maven wrapper availability.
  - **Verification**: Use the installed JDK path and Maven wrapper for later build commands.

- Step 2: Setup Baseline
  - **Rationale**: Capture current build health before the upgrade.
  - **Changes to Make**: Run the baseline Maven compile/test cycle with the current JDK.
  - **Verification**: `./mvnw -q test` (baseline)

- Step 3: Upgrade Build and Dependencies
  - **Rationale**: Update the build to target Java 25 and align the Spring Boot/OpenAPI stack with the newer runtime.
  - **Changes to Make**: Apply the Dependency Changes from the Impact Analysis section.
  - **Verification**: `./mvnw -q -DskipTests compile`

- Step 4: Update Spring Boot 3 Compatibility Code
  - **Rationale**: Spring Boot 3 requires Jakarta namespace changes and Spring Security 6 syntax.
  - **Changes to Make**: Apply the Source Code Changes and any required import adjustments.
  - **Verification**: `./mvnw -q -DskipTests compile`

- Step 5: Final Validation
  - **Rationale**: Confirm the upgraded project builds and all tests pass under Java 25.
  - **Changes to Make**: Resolve any remaining compilation or test issues until full verification passes.
  - **Verification**: `./mvnw -q test`
